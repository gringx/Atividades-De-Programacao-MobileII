import React from "react";
import { Box, Heading, AspectRatio, Image, Text, Center, HStack, Stack, NativeBaseProvider } from "native-base";

const Example = () => {
  return <Box alignItems="center">
      <Box maxW="80" rounded="lg" overflow="hidden" borderColor="coolGray.200" borderWidth="1" _dark={{
      borderColor: "coolGray.600",
      backgroundColor: "gray.700"
    }} _web={{
      shadow: 2,
      borderWidth: 0
    }} _light={{
      backgroundColor: "gray.50"
    }}>
        <Box>
          <AspectRatio w="100%" ratio={16 / 9}>
            <Image source={{
            uri: "https://cdn.meutimao.com.br/_upload/video/2021/06/palmeiras-x-corinthians-palpites-do-meu-timao_lfull.jpg"
          }} alt="image" />
          </AspectRatio>
          <Center bg="blue.500" _dark={{
          bg: "blue.400"
        }} _text={{
          color: "warmGray.50",
          fontWeight: "700",
          fontSize: "xs"
        }} position="absolute" bottom="0" px="3" py="1.5">
            Derby Sul-Americano
          </Center>
        </Box>
        <Stack p="4" space={3}>
          <Stack space={2}>
            <Heading size="md" ml="-1">
              Derby Palmeiras X Corithians
            </Heading>
            <Text fontSize="xs" _light={{
            color: "black.500"
          }} _dark={{
            color: "black.400"
          }} fontWeight="600" ml="-0.5" mt="-1">
            Gigantes paulistas que sempre brigaram
            </Text>
          </Stack>
          <Text fontWeight="600">
              A primeira partida entre Corinthians e o Palmeiras aconteceu em 06 de maio de 1917, há 105 anos.
          </Text>
          <HStack alignItems="center" space={4} justifyContent="space-between">
            <HStack alignItems="center">
              <Text color="coolGray.600" _dark={{
              color: "warmGray.100"
            }} fontWeight="400">
                1 Hora Atrás
              </Text>
            </HStack>
          </HStack>
        </Stack>
      </Box>
    </Box>;
};

    export default () => {
        return (
          <NativeBaseProvider>
            <Center flex={1} px="3">
                <Example />
            </Center>
          </NativeBaseProvider>
        );
    };
    